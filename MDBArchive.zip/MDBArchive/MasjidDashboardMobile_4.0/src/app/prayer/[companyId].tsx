import { processPrayerTimeMessage } from '@/src/services-react/PrayerTimeMessageProcessor';
import { StackNavigationProp } from '@react-navigation/stack';
import { Company, CompanyData, PrayersDay } from "mdb-core-js";
import React, { useEffect, useState } from "react";
import { BackHandler, Image, Platform, StyleSheet, Text, View } from "react-native";
import { beginCompanyDataInterval, destroyTrackerInterval, } from '../../services/AppService';
import { ConstantsStyles } from "../../services/Constants";
import { processPrayerTime } from "../../services/PrayerTimeProcessor";
import { storeDispatchCompanyData } from "../../store/ReduxStoreService";
import { useTypedSelector } from "../../store/rootReducer";
import { createEmptyPrayerTimeSummaryMessage, PrayerTimeSummaryMessage } from "../../types/react-types";
import { Loading } from '@/src/components/Loading';
import { TodaysDetail } from '@/src/components/prayer/TodaysDetail';
import { PrayerTimeGrid } from '@/src/components/prayer/PrayerTimeGrid';
import { useLocalSearchParams, useRouter } from 'expo-router';

interface Props { }

const PrayerTime: React.FC<Props> = ({ }) => {
    const [prayerTimeMessage, setPrayerTimeMessage] = useState(createEmptyPrayerTimeSummaryMessage());
    const companyData = useTypedSelector(state => state.companyData);
    const { companyId } = useLocalSearchParams<{ companyId: string }>();
    const companyListData = useTypedSelector(state => state.companyListData);
    const selectedCompany = companyListData.companies.find(c => c.id === companyId);
    const router = useRouter();

    // TODO: make prayerTimeMessageInterval part of PrayerTimeSummaryMessage interface
    let prayerTimeMessageInterval: NodeJS.Timeout;
    // TODO: make prayerTimeMessageInterval part of PrayerTimeSummaryMessage interface
    const destroyPrayerTimeMessageInterval = () => {
        if (prayerTimeMessageInterval) {
            clearInterval(prayerTimeMessageInterval);
        }
    }

    // Inits
    useEffect(() => {
        if (isSameCompanySelected(companyData, selectedCompany)) return;
        if (selectedCompany) {
            companyData.company = selectedCompany;
            storeDispatchCompanyData(companyData);
        }

        if (Platform.OS === 'android') {
            const subscription = BackHandler.addEventListener('hardwareBackPress', handleBackButton);
            return () => {
                subscription.remove();
            };
        }
    }, []);


    // Starts CompanyData Interval
    useEffect(() => {
        // Interval to update API prayer and version
        beginCompanyDataInterval(companyData);

        return () => destroyTrackerInterval("CompanyDataInterval", companyData.tracker);
    }, []);



    // Starts  PrayerTimeMessage interval
    useEffect(() => {
        const prayer = companyData.prayer;

        if (!prayer || !prayer.date) {
            return destroyPrayerTimeMessageInterval;
        }

        // Interval to update Azan, Salah and Jammat time messages on screen
        destroyPrayerTimeMessageInterval();
        startPrayerTimeMessage(prayer, setPrayerTimeMessage);
        prayerTimeMessageInterval = setInterval(() => startPrayerTimeMessage(prayer, setPrayerTimeMessage), 1000);

        return destroyPrayerTimeMessageInterval;
    }, [companyData]);

    // const onButtonPress = () => {
    //     BackHandler.removeEventListener('hardwareBackPress', handleBackButton);
    //     // then navigate
    //     // navigate('NewScreen');
    // }


    const handleBackButton = () => {
        BackHandler.exitApp();
        /*
        Alert.alert(
            'Exit App',
            'Exiting the application?', [{
                text: 'Cancel',
                onPress: () => console.log('Cancel Pressed'),
                style: 'cancel'
            }, {
                text: 'OK',
                onPress: () => BackHandler.exitApp()
            }, ], {
                cancelable: false
            }
         )
        */
        return true;
    }


    // Navigate to CompanySelect because there is no selected company
    useEffect(() => {
        if (!companyData || !companyData.company || !companyData.company.id) {
            router.push("/company/company-select");
        }
    }, [companyData]);

    // Interval to update Azan, Salah and Jammat time messages on screen
    const startPrayerTimeMessage = (prayer: PrayersDay, setPrayerTimeMessage: React.Dispatch<React.SetStateAction<PrayerTimeSummaryMessage>>) => {
        const prayerTimeSummary = processPrayerTime(prayer);
        const prayerTimeMessage = processPrayerTimeMessage(prayerTimeSummary);
        setPrayerTimeMessage(prayerTimeMessage);
    }

    return (
        <View style={styles.container}>
            <View style={styles.background}>
                <Image source={require('../../images/background3.png')} style={styles.backgroundImage} />
            </View>
            <View style={styles.content}>
                {(!companyData || !companyData.prayer || !companyData.prayer.date) &&
                    <Loading style={{ color: ConstantsStyles.text.colorLight }} />
                }
                {(companyData && companyData.prayer && companyData.prayer.date) && <>
                    <View style={styles.todaysDetail}>
                        <TodaysDetail
                            prayerTimeMessage={prayerTimeMessage}
                            companyData={companyData} />
                    </View>
                    <View style={{
                        height: 3,
                        alignItems: "center",
                        justifyContent: "center"
                    }}>
                        <View style={{
                            height: 3,
                            backgroundColor: ConstantsStyles.color.lines,
                            borderRadius: 3,
                            width: "70%"
                        }} />
                    </View>
                    <View style={styles.prayerTimeGrid}>
                        <PrayerTimeGrid companyData={companyData} prayerTimeMessage={prayerTimeMessage} prayer={companyData.prayer} />
                    </View>
                </>}

            </View>
        </View>
    );
}

const isSameCompanySelected = (companyData: CompanyData, selectedCompany: Company | undefined) => {
    return companyData && companyData.company && companyData.company.id
        && selectedCompany && selectedCompany.id
        && companyData.company.id !== selectedCompany.id;
}

const styles = StyleSheet.create({
    container: {
    },
    background: {
        height: "100%",
        width: "100%"
    },
    backgroundImage: {
        flex: 1,
        width: undefined,
        height: undefined,
        resizeMode: 'cover'
    },
    content: {
        position: "absolute",
        top: 0,
        height: "100%",
        width: "100%",
        backgroundColor: "#183f62ef" // TODO Change this color for all prayers
    },
    todaysDetail: {
        height: "40%",
        alignContent: "center",
        justifyContent: "center"
    },
    prayerTimeGrid: {
        height: "60%",
        paddingBottom: 15,
        paddingLeft: 5,
        paddingRight: 5,
        alignContent: "center",
        justifyContent: "center"
    }
});


export default PrayerTime;